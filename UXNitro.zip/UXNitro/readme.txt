=== UXNitro ===
Contributors: UXNitro
Donate link: https://uxnitro.com/
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Tags: custom-background, custom-logo, custom-menu, custom-logo, featured-images, flexible-header, footer-widgets, full-width-template, sticky-post, theme-options, threaded-comments, translation-ready, one-column, two-columns, three-columns, left-sidebar, right-sidebar, e-commerce, blog
Requires at least: 4.9
Tested up to: 6.7.1
Stable tag: 0.3.7

== Description ==

UXNitro is fast, lightweight, responsive and super flexible multipurpose theme built with SEO, speed, and usability in mind.
Unleash the power of your imagination with a true WYSIWYG Header & Footer builder (inside the WordPress Customizer) built exclusively for this theme.
The theme works great with any of your favorite page builder likes Elementor, Beaver Builder, SiteOrigin, Thrive Architect, Divi, Visual Composer, etc.
Combined with the Header & Footer builder, you can build any type of websites like shop, business agencies, corporate, portfolio, education, university portal, consulting, church, restaurant, medical and so on.
UXNitro is compatible with all well-coded plugins, including major ones like WooCommerce, OrbitFox, Yoast, BuddyPress, bbPress, etc.
Learn more about the theme and ready to import demo sites at https://uxnitro.com/

== Installation ==

= From within WordPress =
1. Visit "Appearance > Themes > Add New"
1. Search for "UXNitro"
1. Install and activate

== Frequently Asked Questions ==

= Is UXNitro Free? =
Yes! UXNitro is a free theme, and always will be.

= Where can I find documentation? =
UXNitro has extensive documentation you can find [here](https://uxnitro.com/docs/).

= Do you offer support? =
Definitely. We offer support for the free theme in the [WordPress.org forums](https://wordpress.org/support/theme/uxnitro).

We try to answer all questions within 24 hours.

= Where can I find the theme options? =
All of our options can be found in the Customizer in 'Appearance > Customize'.

= Does UXNitro have any widget areas? =
UXNitro has up to 6 widget areas which you can add widgets to in Appearance > Widgets.

= How can I make my site look like your screenshot? =
If you want to replicate the screenshot you see on WordPress.org, please refer to [this article](https://uxnitro.com/docs/).

== Copyright ==

UXNitro WordPress Theme, Copyright 2018 UXNitro.com
UXNitro is distributed under the terms of the GNU GPL

UXNitro bundles the following third-party resources:

Font Awesome Icons, Copyright Dave Gandy

Font Awesome Copyright
Font License- Applies to all desktop and webfont files in the following directory: font-awesome/fonts/.
License: SIL OFL 1.1 - http://scripts.sil.org/OFL
Code License - Applies to all CSS and LESS files in the following directories: font-awesome/css/, font-awesome/less/, and font-awesome/scss/
License: MIT License - http://opensource.org/licenses/mit-license.html

License: SIL Open Font License, version 1.1.
Source: https://fontawesome.com/v4.7.0/license/

Customify Sites Thumbnail Image, Theme Screenshot images from Pexels
License:  https://www.pexels.com/photo-license/ (http://creativecommons.org/publicdomain/zero/1.0 - CC0)

    assets/images/admin/sites_thumbnail.jpg
    https://www.pexels.com/photo/view-of-high-rise-buildings-during-day-time-302769/

    assets/images/default_cover.jpg
    https://www.pexels.com/photo/architectural-design-architecture-buildings-city-374811/

    Theme Screenshot
    https://www.pexels.com/photo/woman-wearing-yellow-scoop-neck-shirt-762084/
    https://www.pexels.com/photo/man-wearing-white-crew-neck-vans-top-and-blue-denim-button-up-jacket-1040881/
    https://www.pexels.com/photo/adult-dark-eyewear-facial-expression-428311/
    https://www.pexels.com/photo/man-wearing-white-and-black-legendary-print-t-shirt-157646/

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
License: MIT
Source: https://necolas.github.io/normalize.css/

Gridlex, Copyright Devlint
License: MIT, https://github.com/devlint/gridlex/blob/master/LICENSE
Source: https://github.com/devlint/gridlex

FitVids, Copyright Chris Coyier
License: WTFPL license, http://sam.zoy.org/wtfpl/
Source: http://css-tricks.com + Dave Rupert - http://daverupert.com - https://github.com/davatron5000/FitVids.js

WP Color Picker Alpha, Copyright kallookoo
Licensed under the GPLv2 license.
Source: https://github.com/kallookoo/wp-color-picker-alpha

